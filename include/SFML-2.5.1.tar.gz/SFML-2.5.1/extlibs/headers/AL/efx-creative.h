/* The tokens that would be defined here are already defined in efx.h. This
 * empty file is here to provide compatibility with Windows-based projects
 * that would include it. */
